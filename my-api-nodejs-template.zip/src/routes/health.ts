import { Router, Request, Response } from 'express';

export const healthRouter = Router();

const startTime = Date.now();

/**
 * Liveness probe — the process is running.
 * Kubernetes restarts the pod if this fails.
 */
healthRouter.get('/', (_req: Request, res: Response) => {
  res.json({ status: 'UP', service: 'my-api', timestamp: new Date().toISOString() });
});

/**
 * Readiness probe — the service can accept traffic.
 * Kubernetes removes the pod from load balancing if this fails.
 */
healthRouter.get('/ready', (_req: Request, res: Response) => {
  const uptimeMs = Date.now() - startTime;
  res.json({
    status: 'READY',
    service: 'my-api',
    uptimeMs,
    timestamp: new Date().toISOString(),
  });
});
