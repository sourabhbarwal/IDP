import express, { Application } from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import { healthRouter } from './routes/health';
import { metricsRouter } from './routes/metrics';
import { requestLogger } from './middleware/logger';

export function createApp(): Application {
  const app = express();

  // Security
  app.use(helmet());
  app.use(cors({ origin: process.env.ALLOWED_ORIGINS?.split(',') ?? false, credentials: true }));
  app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 100, standardHeaders: true, legacyHeaders: false }));

  // Logging
  app.use(requestLogger);

  // Parsing
  app.use(express.json({ limit: '10mb' }));

  // Routes
  app.use('/health', healthRouter);
  app.use('/metrics', metricsRouter);

  // 404 handler
  app.use((_req, res) => res.status(404).json({ error: 'Not found' }));

  return app;
}
