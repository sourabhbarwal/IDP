import 'dotenv/config';
import { createApp } from './app';

const PORT = Number(process.env.PORT ?? 3000);

const app = createApp();

app.listen(PORT, () => {
  console.log(JSON.stringify({ level: 'info', message: 'my-api started', port: PORT, env: process.env.NODE_ENV }));
});

process.on('SIGTERM', () => {
  console.log(JSON.stringify({ level: 'info', message: 'SIGTERM received, shutting down' }));
  process.exit(0);
});
